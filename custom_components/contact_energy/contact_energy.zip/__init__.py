"""Support for Contact Energy sensors."""
